# Bacon AI Design Analysis

## Color Palette
- Background: White/very light pink-cream gradient (#FFF5F5 to #FFFFFF)
- Primary accent: Coral/salmon red (#FF4D4D / #FF6B6B)
- Secondary accent: Bright green (#00FF88)
- Text: Near-black (#111111)
- Highlight text: Coral/salmon for key phrases
- CTA buttons: Coral/salmon with rounded pill shape

## Typography
- Headlines: Very large, bold, black (700-900 weight), mixed with colored accent words
- Body: Clean sans-serif, medium weight
- Section labels: Small caps, letter-spaced, muted color

## Layout Structure
1. **Sticky nav** — minimal, logo left, nav center, CTA right (pill button)
2. **Hero** — HUGE headline with floating photorealistic product images scattered around text (not in a grid — organic floating layout). Images have rounded corners, slight shadows. Text in center with CTA below.
3. **Social proof bar** — logos of trusted companies + stats (6000+ Users, 40k+ Content, 324M Views)
4. **Product walkthrough** — "From Blank Canvas to Brand Magic" — video embed in a laptop/monitor frame
5. **Use cases** — Left: accordion list of use cases. Right: visual showing platform connections (hub-and-spoke with logos)
6. **"Every Creative" section** — Tab switcher (Images/Videos/UGC), then scrolling gallery of photorealistic ad examples
7. **Models section** — Left text, right floating app icons (colorful, 3D-style)
8. **As seen on** — media logos row
9. **Comparison table** — "Why Bacon Outperforms" with competitor comparison bars
10. **Testimonials** — Card grid with user photos and quotes
11. **Final CTA** — "Start scaling your sales, not your workload"
12. **Footer** — minimal

## Key Design Principles
- **Benefit-first**: Every section headline is a benefit ("Ads That Convert", "Fill Your Social Calendar Instantly", "Launch New Products in Minutes")
- **Photorealistic imagery**: Real people using products, real ad examples floating around hero
- **Organic floating layout**: Images scattered at angles, not in rigid grids
- **Mixed text colors**: Black + coral accent words in same headline
- **Pill-shaped CTAs**: Coral/salmon background, white text, very rounded
- **Section labels**: Small uppercase tracking labels above each section title
- **Light background**: Mostly white/cream, not dark
- **Energy**: Bold, confident, no fluff

## For ARIA Adaptation
- Keep ARIA dark theme for the app itself
- Landing page: Use ARIA's dark theme but with ARIA's electric blue/purple accent colors
- Floating images: Show marketers, dashboards, campaign results, happy customers
- Benefits to highlight:
  1. "Your entire marketing team, in one conversation"
  2. "Launch campaigns in minutes, not weeks"
  3. "Never run out of content ideas"
  4. "Know exactly what's working before you spend"
  5. "Your brand voice, remembered forever"
  6. "From idea to published in one message"
