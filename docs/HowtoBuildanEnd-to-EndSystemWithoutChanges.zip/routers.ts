    const db = await getDb(); if (!db) return { impressions: 0, clicks: 0, conversions: 0, spend: 0, revenue: 0, ctr: "0%", roas: "0" };
    const conditions: ReturnType<typeof eq>[] = [eq(analyticsEvents.userId, ctx.user.id)];
    if (input.campaignId) conditions.push(eq(analyticsEvents.campaignId, input.campaignId));
    const events = await db.select().from(analyticsEvents).where(and(...conditions)).limit(1000);
    const totals = events.reduce((acc, e) => ({ impressions: acc.impressions + (e.impressions ?? 0), clicks: acc.clicks + (e.clicks ?? 0), conversions: acc.conversions + (e.conversions ?? 0), spend: acc.spend + (e.spend ?? 0), revenue: acc.revenue + (e.revenue ?? 0) }), { impressions: 0, clicks: 0, conversions: 0, spend: 0, revenue: 0 });
    return { ...totals, ctr: totals.impressions > 0 ? `${((totals.clicks / totals.impressions) * 100).toFixed(2)}%` : "0%", roas: totals.spend > 0 ? (totals.revenue / totals.spend).toFixed(2) : "0", period: input.period ?? "month" };
  }),
});

const crmRouter = router({
  leads: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(leads).where(eq(leads.userId, ctx.user.id)).orderBy(desc(leads.createdAt)); }),
  deals: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(deals).where(eq(deals.userId, ctx.user.id)).orderBy(desc(deals.createdAt)); }),
  updateLeadStatus: protectedProcedure.input(z.object({ id: z.number(), status: z.string() })).mutation(async ({ ctx, input }) => { const db = await getDb(); if (!db) return { success: false }; await db.update(leads).set({ status: input.status as "new" }).where(and(eq(leads.id, input.id), eq(leads.userId, ctx.user.id))); return { success: true }; }),
});

const brandRouter = router({
  voices: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(brandVoices).where(eq(brandVoices.userId, ctx.user.id)).orderBy(desc(brandVoices.createdAt)); }),
  kit: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return null; const [k] = await db.select().from(brandKits).where(eq(brandKits.userId, ctx.user.id)).limit(1); return k ?? null; }),
  updateKit: protectedProcedure.input(z.object({ name: z.string().optional(), primaryColor: z.string().optional(), secondaryColor: z.string().optional(), fontPrimary: z.string().optional(), logoUrl: z.string().optional() })).mutation(async ({ ctx, input }) => {
    const db = await getDb(); if (!db) return { success: false };
    const existing = await db.select().from(brandKits).where(eq(brandKits.userId, ctx.user.id)).limit(1);
    if (existing.length > 0) { await db.update(brandKits).set(input).where(eq(brandKits.userId, ctx.user.id)); } else { await db.insert(brandKits).values({ userId: ctx.user.id, name: input.name ?? "My Brand", ...input }); }
    return { success: true };
  }),
});

const schedulerRouter = router({
  queue: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(scheduledPosts).where(eq(scheduledPosts.userId, ctx.user.id)).orderBy(scheduledPosts.scheduledAt).limit(100); }),
  cancel: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => { const db = await getDb(); if (!db) return { success: false }; await db.update(scheduledPosts).set({ status: "canceled" }).where(and(eq(scheduledPosts.id, input.id), eq(scheduledPosts.userId, ctx.user.id))); return { success: true }; }),
});

const dspRouter = router({
  wallet: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb(); if (!db) return null;
    const [w] = await db.select().from(dspAdWallets).where(eq(dspAdWallets.userId, ctx.user.id)).limit(1);
    if (!w) { await db.insert(dspAdWallets).values({ userId: ctx.user.id, balanceCents: 0 }); return { id: 0, userId: ctx.user.id, balanceCents: 0 }; }
    return w;
  }),
  campaigns: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(dspCampaigns).where(eq(dspCampaigns.userId, ctx.user.id)).orderBy(desc(dspCampaigns.createdAt)); }),
});

const reviewsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(reviews).where(eq(reviews.userId, ctx.user.id)).orderBy(desc(reviews.createdAt)); }),
  sources: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(reviewSources).where(eq(reviewSources.userId, ctx.user.id)); }),
});

const reportsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(reports).where(eq(reports.userId, ctx.user.id)).orderBy(desc(reports.createdAt)); }),
  getByToken: publicProcedure.input(z.object({ token: z.string() })).query(async ({ input }) => { const db = await getDb(); if (!db) return null; const [r] = await db.select().from(reports).where(eq(reports.shareToken, input.token)).limit(1); return r ?? null; }),
});

const teamRouter = router({
  members: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(teamMembers).where(eq(teamMembers.userId, ctx.user.id)); }),
  approvals: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(approvalWorkflows).where(eq(approvalWorkflows.requestedBy, ctx.user.id)).orderBy(desc(approvalWorkflows.createdAt)); }),
});

const settingsRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return null; const [s] = await db.select().from(userSettings).where(eq(userSettings.userId, ctx.user.id)).limit(1); return s ?? null; }),
  update: protectedProcedure.input(z.object({ timezone: z.string().optional(), defaultLanguage: z.string().optional(), emailNotifications: z.boolean().optional(), pushNotifications: z.boolean().optional() })).mutation(async ({ ctx, input }) => {
    const db = await getDb(); if (!db) return { success: false };
    const existing = await db.select().from(userSettings).where(eq(userSettings.userId, ctx.user.id)).limit(1);
    if (existing.length > 0) { await db.update(userSettings).set(input).where(eq(userSettings.userId, ctx.user.id)); } else { await db.insert(userSettings).values({ userId: ctx.user.id, ...input }); }
    return { success: true };
  }),
  integrations: protectedProcedure.query(async ({ ctx }) => { const db = await getDb(); if (!db) return []; return db.select().from(integrations).where(eq(integrations.userId, ctx.user.id)); }),